$(document).ready(function() {
	$('.gall__list').lightGallery({
	    thumbnail: false,
	    // animateThumb: false,
	    selector: '.gall__it-zoom',
	    // showThumbByDefault: false
	});
	// alert('wewe');
});